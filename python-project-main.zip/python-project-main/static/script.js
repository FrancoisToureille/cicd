var date = new Date();
document.getElementById("time").innerHTML = date;
